'use strict';
var dataProvider = require('../../../data/transactiontest/{transactionId}/{campaignId}.js');
/**
 * Operations on /transactiontest/{transactionId}/{campaignId}
 */
module.exports = {
    /**
     * summary: 
     * description: 
     * parameters: transactionId, campaignId
     * produces: application/json, text/json
     * responses: 200
     */
    get: function transactiontest(req, res, next) {

        /** get parameters */
        var tId = req.params.transactionId;
        var cId = req.params.campaignId;

        var echo = {
            transactionId: tId,
            campaignId: cId
        }
        res.json(echo);
    }
};
